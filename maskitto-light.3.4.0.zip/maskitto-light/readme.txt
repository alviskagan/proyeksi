Licence statements


Photos - Pexels.com:
Licensed under the Creative Commons Zero (CC0) license.

	Screenshot slide photo - http://www.pexels.com/photo/2867/
	Included photo "bloghead.jpg" - http://www.pexels.com/photo/4004/


Font - Font Awesome:
Licensed under the SIL Open Font License (OFL).


Code - Font Awesome:
Licensed under the MIT license.


Custom header:
Functionality is limited to images only.


Script - Bootstrap
Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)


Script - jQuery Waypoints
Dual licensed under the MIT license and GPL license.


Script - jQuery Touch Optimized Sliders
Licensed under the MIT license.


Script - jQuery Counterup
Released under the GPL v2 License.


Script - Maplace
Licensed under the MIT license.


Script - Slick
Licensed under the MIT license.


Script - SmoothScroll
Licensed under the terms of the MIT license.


Plugin - Redux Framework
Released under the GPL v2 or later.


Plugin - TGM-Plugin-Activation
Released under the GPL v2 or later.


Plugin - wp_bootstrap_navwalker
Released under the GPL v2 License.