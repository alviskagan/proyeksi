<?php 

	/*template name: Contact page */
    get_template_part( 'page', '' );
    
?>